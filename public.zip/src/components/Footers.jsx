import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './footers.css'; // Custom styles
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faTwitter, faInstagram, faLinkedinIn } from '@fortawesome/free-brands-svg-icons';
import { Images } from './../image/index';

function App() {
  return (
    <>
      <div className="footer bg-red text-white py-4">
        <div className="container">
          <div className="row">

            <div className="col-md-3">
              <h2 className=''>OPD Registration</h2>
              <div className='opds'></div>
              <p>
                ओपीडी पंजीकरण काउंटर में स्कैन और शेयर प्रणाली शुरू की गई है, जहाँ आप ABHA नंबर के माध्यम से या ईहॉस्पिटल ऐप (प्लेस्टोर के माध्यम से इंस्टॉल किया जा सकता है) के माध्यम से स्कैन कर सकते हैं और पंजीकरण टोकन नंबर प्राप्त कर सकते हैं.
              </p>
            </div>

            <div className='col-md-2'></div>

            {/* Navigation */}
            <div className="col-md-3">
              <h2 className=''>Navigation</h2>
              <div className='opds2'></div>
              <ul className="list-unstyled">
                <li className="hover-text"><span className="black-dot"></span> Copyright Policies</li>
                <li className="hover-text"><span className="black-dot"></span> Terms & Conditions</li>
                <li className="hover-text"><span className="black-dot"></span> Disclaimer</li>
                <li className="hover-text"><span className="black-dot"></span> Hyperlink Policy</li>
                <li className="hover-text"><span className="black-dot"></span> Privacy Policy</li>
                <li className="hover-text"><span className="black-dot"></span> Old Website</li>
              </ul>
            </div>

            {/* Contact */}
            <div className="col-md-3 contact-section">
              <h2 className=''>Contact</h2>
              <div className='opds3'></div>
              <p><i className="fas fa-map-marker-alt"></i> Bhagatpatti Naugachia <br />Bhagalpur, Bihar - 834009, Bihar, India<br />Email: msrimsranchi@gmail.com</p>
              <p><i className="fas fa-phone"></i> Phone: +91 87898 32218</p>
              <p><i className="fas fa-exclamation-circle"></i> Emergencyn Number: +91 88774 71745</p>
              {/* <p><i className="fas fa-ambulance"></i> Ambulance: +91-651-2547260</p> */}
            </div>
          </div>
        </div>

        {/* <div className="row social-icons-container ">
          <div className='col-10'></div>
        <div className="ool-2 social-icons">
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faFacebookF} size="2x" />
          </a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faTwitter} size="2x" />
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faInstagram} size="2x" />
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faLinkedinIn} size="2x" />
          </a>
        </div>
      </div> */}

      <div className='row w-100'>
        <div className='col-1'></div>
        <div className='col-2'><img src={Images.Image40}/></div>
        <div className='col-5'></div>
        <div className='col-2 '>
          <h4 className="connect">Connect with Us</h4>
        <div className="social-icons">
          <a href="https://www.facebook.com/sumit.bhagat.1654700" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faFacebookF} size="2x" />
          </a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faTwitter} size="2x" />
          </a>
          <a href="https://www.instagram.com/sumitbhagat9939/" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faInstagram} size="2x" />
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
            <FontAwesomeIcon icon={faLinkedinIn} size="2x" />
          </a>
        </div>
        </div>

        <div className='col-1'></div>

      </div>

      <div>
        <hr></hr>

<div className='d-flex flex-row justify-content-center'>
  <div className='mt-1'>© 1960-2024 Rajendra Institute of Medical Sciences . All Rights Reserved. | © Technology Partner : </div>
  <div><img className='px-2 ed ' src={Images.Image33}/></div>
  <div className='mt-1 computer'>COMPUTER Ed.</div>
</div>

      </div>

      </div>

    
     
    </>
  );
}

export default App;
