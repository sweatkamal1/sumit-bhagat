// src/components/About.js
import React from 'react';
import { Container, Row, Col, Image } from 'react-bootstrap';
import { Images } from './../image/index';
import './about.css';

const About = () => {
  return (
    <div>
    <div className='divs'></div>

    <Container id="about" className="bg my-5">
      <Row>
        <Col md={4}>
          {/* Set the image to be circular */}
          <Image src={Images.Image} roundedCircle fluid />
        </Col>
        <Col md={8}>
          <h2>About Me</h2>
          <p>
            Hello! I'm Sumit Bhagat. I am from Naugachia Bhagalpur, Bihar. I am a Social Worker and have worked on many social activities.
          </p>
          <p>
            When I'm not coding, I enjoy photography, exploring new technologies, and spending time with my family. 
            My goal is to constantly improve and learn new skills to better serve my clients and create more impactful work.
          </p>
        </Col>
      </Row>
    </Container>
    </div>
  );
};

export default About;
