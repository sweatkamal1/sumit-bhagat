import React from 'react';
import { Container, Row, Col, Image, Card } from 'react-bootstrap';

const PoliticalCarrier = () => {
  return (
    <Container className="mt-5">
      {/* Title Section */}
      <Row className="text-center mb-4">
        <Col>
          <h1>Political Career</h1>
          <p>A journey through political achievements and milestones.</p>
        </Col>
      </Row>

      {/* Photo Section */}
      <Row className="mb-4">
        <Col md={4}>
          <Card>
            <Image src="https://via.placeholder.com/300x200" fluid rounded />
            <Card.Body>
              <Card.Title>Early Days</Card.Title>
              <Card.Text>
                Description of political activities and achievements during the early career phase.
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card>
            <Image src="https://via.placeholder.com/300x200" fluid rounded />
            <Card.Body>
              <Card.Title>Major Achievement</Card.Title>
              <Card.Text>
                Highlights of major political milestones and success stories.
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card>
            <Image src="https://via.placeholder.com/300x200" fluid rounded />
            <Card.Body>
              <Card.Title>Present Day</Card.Title>
              <Card.Text>
                Recent political endeavors and ongoing contributions.
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Additional Content Section */}
      <Row className="text-center">
        <Col>
          <h3>More about the Political Journey</h3>
          <p>
            Explore various facets of the political career, including public speeches, community work, and international relations.
          </p>
        </Col>
      </Row>
    </Container>
  );
};

export default PoliticalCarrier;
