import React from 'react';
import Header from './components/Header';
import About from './components/About';
import Portfolio from './components/Portfolio';
import Contact from './components/Contact';
import Footers from "./components/Footers"
import PoliticalCarrier from "./components/PoliticalCarrier"
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <div>
      <Header />
      <About />
      <Portfolio />
      <PoliticalCarrier/>
      <Contact />
      <Footers/>
    </div>
  );
}

export default App;
