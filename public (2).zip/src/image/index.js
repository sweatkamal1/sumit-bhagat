export const Images = {
    Image:"./asets/sumit_profile.jpg",
    Image1:"./asets/plant.jpg",
    Image2:"./asets/samman.jpg",
    Image3:"./asets/police.jpg",
    Image4:"./asets/raktdan.jpg",
    Image5:"./asets/achivement.jpg",
    Image6:"./asets/naugachia.jpg"
}