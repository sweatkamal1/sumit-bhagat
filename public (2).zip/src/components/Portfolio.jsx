// src/components/Portfolio.js
import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { Images } from './../image/index';

const Portfolio = () => {
  return (
    <Container id="portfolio" className="my-5">
      <h2>My Achievement</h2>
      <Row>
        <Col md={4}>
          <Card>
            <Card.Img
              variant="top"
              src={Images.Image1}
              style={{ height: '250px', width: '100%', objectFit: 'cover' }} // Adjust the height and width
            />
            <Card.Body>
              {/* <Card.Title>Project 1</Card.Title> */}
              <Card.Text>
                भागलपुर के प्लांटमेन के बेताज बादशाह विनम्र स्वभाव के धनी भाई राजा बोस जी ने मुझे अपने 
                पुष्प वाटिका से उपहार स्वरूप मुझे पौधा प्रदान किया। शानदार आतिथ्य स्वागत के लिये उनको बहुत बहुत धन्यवाद।
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card>
            <Card.Img
              variant="top"
              src={Images.Image2}
              style={{ height: '250px', width: '100%', objectFit: 'cover' }} // Adjust the height and width
            />
            <Card.Body>
              {/* <Card.Title>Project 2</Card.Title> */}
              <Card.Text>A short description of the project.</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card>
            <Card.Img
              variant="top"
              src={Images.Image3}
              style={{ height: '250px', width: '100%', objectFit: 'cover' }} // Adjust the height and width
            />
            <Card.Body>
              {/* <Card.Title>Project 3</Card.Title> */}
              <Card.Text>A short description of the project.</Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Portfolio;
